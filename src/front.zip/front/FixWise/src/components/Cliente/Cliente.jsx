import React from 'react'

const Cliente = (props) => {
  return (
    <div>
        <li>{props.name}</li>
    </div>
  )
}

export default Cliente