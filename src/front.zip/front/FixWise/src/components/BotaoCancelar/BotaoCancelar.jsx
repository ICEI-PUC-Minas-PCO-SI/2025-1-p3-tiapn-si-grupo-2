import React from 'react'

const BotaoCancelar = () => {
  return (
    <div>
      <input className='shadow-sm ring p-2 hover:cursor-pointer w-[80px] rounded-sm' type="button" value="Cancelar"/>
    </div>
  )
}

export default BotaoCancelar
