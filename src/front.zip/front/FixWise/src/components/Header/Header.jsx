import React from 'react'

const Header = () => {
  return (
    <div className='col-span-2 bg-blue-600 text-white p-4'>
       
    </div>
  )
}

export default Header
