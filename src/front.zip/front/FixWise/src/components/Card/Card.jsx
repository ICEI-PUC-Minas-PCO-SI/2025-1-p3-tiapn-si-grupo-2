export default function Card() {
    return (
        <>
            <div className="card">
                
            </div>
        </>
    )
}