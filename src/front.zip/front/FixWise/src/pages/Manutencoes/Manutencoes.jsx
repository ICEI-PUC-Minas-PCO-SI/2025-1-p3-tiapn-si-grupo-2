import React from 'react'

const Manutencoes = () => {
  return (
    <div>
      
    </div>
  )
}

export default Manutencoes
