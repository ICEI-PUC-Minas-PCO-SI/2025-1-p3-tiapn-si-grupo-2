import React from 'react'

const Configuracoes = () => {
  return (
    <div>
      
    </div>
  )
}

export default Configuracoes
