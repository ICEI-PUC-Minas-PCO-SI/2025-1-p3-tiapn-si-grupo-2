import React from 'react'

const EquipamentosExternos = () => {
  return (
    <div>
      
    </div>
  )
}

export default EquipamentosExternos
