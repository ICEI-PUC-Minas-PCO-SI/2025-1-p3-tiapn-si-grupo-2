import React from 'react'

const EquipamentosInternos = () => {
  return (
    <div>
      
    </div>
  )
}

export default EquipamentosInternos
